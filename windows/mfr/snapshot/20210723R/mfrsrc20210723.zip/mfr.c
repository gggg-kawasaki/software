#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <time.h>

	int is_debug;

int main(int argc, char **argv){
    int data[1024];
	int i,j;
	int k;
	char l[2];

//	int is_ts;
//	int is_td;
//	int is_ta;
//	int is_ta_ch;
//	int is_ev_x;
	int is_ev_d;
	int is_ev_d_n;
	int is_ev_d_s;
	int ev_d;
	int is_ev_s;
	int is_ev_s_n;
	int is_ev_s_d;
	int is_ev_s_s;
	int ev_s;
//	int is_rst;
//	int is_mode;
//	int is_format;
//    char is_ta_sfile[512];
//    char is_ev_x_b[512];
//    char is_ev_x_a[512];
    char is_ev_s_e[512];
//    int ev_s_e[512];

	int header;
	int track;
	int time_div;
	int ch;
	int chunksize;
	int chunksize_new;
	int deltatime;
	int datalength;
	int tr_num;
	int ev_num;
	int ev_prev;
	int ev_cnt;
	int ev_typ;

	char OutFileName[512];
    FILE *InFile,*OutFile,*SFile;

	is_debug=1;
	
//	is_ts=-1;
//	is_td=-1;
//	is_ta=-1;
//	is_ta_ch=-1;
//	is_ev_x=-1;
	is_ev_d=-1;
	is_ev_d_n=-1;
	is_ev_d_s=-1;
	is_ev_s=-1;
	is_ev_s_n=-1;
	is_ev_s_d=-1;
	is_ev_s_s=-1;
//	is_rst=-1;
//	is_mode=-1;
//	is_format=-1;
	ev_d=0;
	ev_s=0;
	
	track=0;
	time_div=0;
	ch=0;

	if(argc<3){
		printf("MFR: standard Midi File Retoucher\n");
		printf("mfr <infile> <outfile> <options...>\n");
		printf("option:\n");
//		printf("-f [x] : force output format(0/1)\n");
//		printf("-m [s] : mode(0:insert/1:overwrite)\n");
//		printf("-r [s] : add reset(0:gm/1:gs/2:xg) to track 1\n");
		printf("-a [t] [n] [d] [hex string of event] : add nth event of track t at deltatime d\n");
		printf("-d [t] [n] [size of event and deltatime] : delete nth event of track t\n");
//		printf("-x [t] [hex string] [hex string] : exchange event of track t\n");
//		printf("-ta [l] [m] [sfile] : Add sfile as track l ch m\n");
//		printf("-td [l] : Delete track l\n");
//		printf("-ts [l] : Save only header and track l\n");
		printf("-msg_off : disable analyze message\n");
		exit(0);
	}
    InFile = fopen(argv[1],"rb" );
    if((InFile==NULL)||(ferror(InFile))){
		printf(" Input File Error\n"); 
		exit(0);
	}
    OutFile = fopen(argv[2],"wb" );
    if((OutFile==NULL)||(ferror(OutFile))){
		printf(" Output File Error\n"); 
		exit(0);
	}
	// initialize array
//	for(i=0;i<512;i++) is_ta_sfile[i]=0x2d;
//	for(i=0;i<512;i++) is_ev_x_b[i]=0x2d;
//	for(i=0;i<512;i++) is_ev_x_a[i]=0x2d;
	for(i=0;i<512;i++) is_ev_s_e[i]=0x2d;

	if(argc>3){
		for(i=3;i<argc;i++) {
			if (strncmp(argv[i],"-msg_off",8) == 0){
				is_debug=0;
//			} else if (strncmp(argv[i],"-ts",3) == 0){
//				is_ts = atoi(argv[++i]);
//			} else if (strncmp(argv[i],"-td",3) == 0){
//				is_td = atoi(argv[++i]);
//			} else if (strncmp(argv[i],"-ta",3) == 0){
//				is_ta = atoi(argv[++i]);
//				is_ta_ch = atoi(argv[++i]);
////				strncpy(is_ta_sfile,argv[++i],512);
//			    SFile = fopen(argv[++i],"rb" );
//			    if((SFile==NULL)||(ferror(SFile))){
//					printf(" Setup File Error\n"); 
//					exit(0);
//				}
//			} else if (strncmp(argv[i],"-x",2) == 0){
//				is_ev_x = atoi(argv[++i]);
//				strncpy(is_ev_x_b,argv[++i],512);
//				strncpy(is_ev_x_a,argv[++i],512);
			} else if (strncmp(argv[i],"-a",2) == 0){
				is_ev_s = atoi(argv[++i]);
				is_ev_s_n = atoi(argv[++i]);
				is_ev_s_d = atoi(argv[++i]);
				strncpy(is_ev_s_e,argv[++i],512);
			} else if (strncmp(argv[i],"-d",2) == 0){
				is_ev_d = atoi(argv[++i]);
				is_ev_d_n = atoi(argv[++i]);
				is_ev_d_s = atoi(argv[++i]);
//			} else if (strncmp(argv[i],"-r",2) == 0){
//				is_rst = atoi(argv[++i]);
//			} else if (strncmp(argv[i],"-m",2) == 0){
//				is_mode = atoi(argv[++i]);
//			} else if (strncmp(argv[i],"-f",2) == 0){
//				is_format = atoi(argv[++i]);
			} else {
				fprintf(stderr,"Unknown parameter %s\n",argv[i]);
				exit(-1);
			}
		}
	}

	i=0;
	if(is_debug){
//		printf("is_ts=%d, is_td=%d, is_ta=%d, is_ta_ch=%d\n",is_ts,is_td,is_ta,is_ta_ch);
//		printf("is_ev_s=%2d, is_ev_s_n=%2d, is_ev_s_d=%8d\n",is_ev_s,is_ev_s_n,is_ev_s_d);
//		printf("is_ev_d=%2d, is_ev_d_n=%2d, is_ev_d_s=%8d\n",is_ev_d,is_ev_d_n,is_ev_d_s);
//		printf("is_rst=%d, is_mode=%d, is_format=%d, is_debug=%d\n",is_rst,is_mode,is_format,is_debug);
//		printf("is_ta_sfile : %s\n",is_ta_sfile);
//		printf("is_ev_x_b : %s\n",is_ev_x_b);
//		printf("is_ev_x_a : %s\n",is_ev_x_a);
//		printf("is_ev_s_e : %s\n",is_ev_s_e);
//		for(i=0;i<512;i++) printf("%02x",is_ev_s_e[i]);
//		printf("\n");
		printf("//----------------------------------------------------------\n");
		printf("//MFR: Ver. 20210716\n");
		printf("//----------------------------------------------------------\n");
		printf("//----------------------------------------------------------\n");
		printf("//Option\n");
		printf("//----------------------------------------------------------\n");
		if(is_ev_s!=-1){
			printf("Add Event:\n");
			printf(" Track=%2d, Event No.=%2d, Delta Time=%8d\n",is_ev_s,is_ev_s_n,is_ev_s_d);
			is_ev_s_s=0;
			printf(" Event : ");
			for(i=0;i<512;i+=2) {
				strncpy(l,&is_ev_s_e[i],2);
				if(*l!=0x00){
					printf("%02X",strtol(l, NULL, 16));
//					fprintf(OutFile,"%c",strtol(l, NULL, 16));
					is_ev_s_s++;
				}
			}
			printf("\n");
			if(is_ev_s_d >= 0x200000) is_ev_s_s+=4;
			if(is_ev_s_d >= 0x4000) is_ev_s_s+=3;
			if(is_ev_s_d >= 0x80) is_ev_s_s+=2;
			if(is_ev_s_d <  0x80) is_ev_s_s+=1;
			printf(" Event Size=%8d\n",is_ev_s_s);
		}
		if(is_ev_d!=-1){
			printf("Delete Event:\n");
			printf(" Track=%2d, Event No.=%2d\n Event Size=%8d\n",is_ev_d,is_ev_d_n,is_ev_d_s);
		}
		printf("//----------------------------------------------------------\n");
	}
//	for(i=3;i<argc;i++) {
//		printf("%d : %s\n",i,argv[i]);
//	}
//	printf("%d\n",i++);
	i=0;j=0;k=0;
	tr_num=0;
    while(k==0){ 
		//ChunkID
		// remove bytes to header
		while((!(((data[0]&0xFF)==0x4D)&&((data[1]&0xFF)==0x54)&&((data[2]&0xFF)==0x68)&&((data[3]&0xFF)==0x64)))&& 
			  (!(((data[0]&0xFF)==0x4D)&&((data[1]&0xFF)==0x54)&&((data[2]&0xFF)==0x72)&&((data[3]&0xFF)==0x6B)))){ 
			data[0]=data[1];
			data[1]=data[2];
			data[2]=data[3];
			data[3] = fgetc(InFile);
			if(data[3]==EOF){
				printf("EOF is detected.\n");
				exit(0);
			}

//			if(is_debug){
//				printf("  SearchStr:%X%X%X%X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF);
//			}

		}
		header=0;
		if((((data[0]&0xFF)==0x4D)&&((data[1]&0xFF)==0x54)&&((data[2]&0xFF)==0x68)&&((data[3]&0xFF)==0x64))){
			header=1;
		}
		if(header==1){
			//----------------------------------------------------------
			//Header Chunk
			//----------------------------------------------------------
			if(is_debug){
				printf("//----------------------------------------------------------\n");
				printf("//Header Chunk\n");
			}
			if(is_debug){
				printf("  Chunk ID:%c%c%c%c\n",data[0],data[1],data[2],data[3]);
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			fprintf(OutFile,"%c",data[2]);
			fprintf(OutFile,"%c",data[3]);
			//ChunkSize
			data[0] = fgetc(InFile);
			data[1] = fgetc(InFile);
			data[2] = fgetc(InFile);
			data[3] = fgetc(InFile);
			if(is_debug){
				printf("  Chunk Size:%x%x%x%x\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF);
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			fprintf(OutFile,"%c",data[2]);
			fprintf(OutFile,"%c",data[3]);
			//FormatType
			data[0] = fgetc(InFile);
			data[1] = fgetc(InFile);
			if(is_debug){
				printf("  Format Type:%x%x\n",data[0]&0xFF,data[1]&0xFF);
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			//Number of Track
			data[0] = fgetc(InFile);
			data[1] = fgetc(InFile);
			if(is_debug){
				printf("  Number of Track:%x%x\n",data[0]&0xFF,data[1]&0xFF);
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			track=(data[0]&0xFF)*256+(data[1]&0xFF);
			//Time Division
			data[0] = fgetc(InFile);
			data[1] = fgetc(InFile);
			if(is_debug){
				printf("  Time Division:%x%x (%4d)%\n",data[0]&0xFF,data[1]&0xFF,(data[0]&0xFF)*256+(data[1]&0xFF));
			}
			time_div=(data[0]&0xFF)*256+(data[1]&0xFF);
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			if(is_debug){
				printf("//----------------------------------------------------------\n");
			}
		}//End header
		else { //Track
			i++;tr_num++;
			ev_num=1;
			if(is_debug){
				printf("//----------------------------------------------------------\n");
				printf("//Header Chunk (Tr:%2d)\n",tr_num);
			}
			if(is_debug){
				printf("  Chunk ID:%c%c%c%c\n",data[0],data[1],data[2],data[3]);
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			fprintf(OutFile,"%c",data[2]);
			fprintf(OutFile,"%c",data[3]);
			//ChunkSize
			data[0] = fgetc(InFile);
			data[1] = fgetc(InFile);
			data[2] = fgetc(InFile);
			data[3] = fgetc(InFile);
			chunksize=(data[0]&0xFF)*256*256*256+(data[1]&0xFF)*256*256+(data[2]&0xFF)*256+(data[3]&0xFF);
			if(is_debug){
				printf("  Chunk Size:%02x%02x%02x%02x(%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,chunksize);
			}
			if((is_ev_d == tr_num)||(is_ev_s == tr_num)){
				chunksize_new=chunksize;
				if(is_ev_d == tr_num) chunksize_new=chunksize_new-is_ev_d_s;
				if(is_ev_s == tr_num) chunksize_new=chunksize_new+is_ev_s_s;
				data[0]=(chunksize_new >> 24)&0xFF;
				data[1]=(chunksize_new >> 16)&0xFF;
				data[2]=(chunksize_new >>  8)&0xFF;
				data[3]=(chunksize_new      )&0xFF;
				if(is_debug){
					printf("  Chunk Size:%02x%02x%02x%02x(%8d) ****** Updated ******\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,chunksize_new);
				}
			}
			fprintf(OutFile,"%c",data[0]);
			fprintf(OutFile,"%c",data[1]);
			fprintf(OutFile,"%c",data[2]);
			fprintf(OutFile,"%c",data[3]);
			while(chunksize>0){
				//Add event option
				if((is_ev_s == tr_num)&&(is_ev_s_n == ev_num)){
					if(is_debug){
						printf("event #%3d : %8d ****** Added ******\n",tr_num,ev_num);
					}
					deltatime=is_ev_s_d;
					data[0] = 0x00;
					data[1] = 0x00;
					data[2] = 0x00;
					data[3] = 0x00;
					if(is_ev_s_d >= 0x200000){
						data[0]=0x80 | ((deltatime >> 21) & 0x7F);
						data[1]=0x80 | ((deltatime >> 14) & 0x7F);
						data[2]=0x80 | ((deltatime >>  7) & 0x7F);
						data[3]=0x00 | ((deltatime      ) & 0x7F);
						fprintf(OutFile,"%c",data[0]);
						fprintf(OutFile,"%c",data[1]);
						fprintf(OutFile,"%c",data[2]);
						fprintf(OutFile,"%c",data[3]);
						if(is_debug){
							printf("  Delta Time:%02X%02X%02X%02X(%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,deltatime);
						}
					} else if(is_ev_s_d >= 0x4000){
						data[0]=0x80 | ((deltatime >> 14) & 0x7F);
						data[1]=0x80 | ((deltatime >>  7) & 0x7F);
						data[2]=0x00 | ((deltatime      ) & 0x7F);
						fprintf(OutFile,"%c",data[0]);
						fprintf(OutFile,"%c",data[1]);
						fprintf(OutFile,"%c",data[2]);
						if(is_debug){
							printf("  Delta Time:%02X%02X%02X  (%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,deltatime);
						}
					} else if(is_ev_s_d >= 0x80){
						data[0]=0x80 | ((deltatime >>  7) & 0x7F);
						data[1]=0x00 | ((deltatime      ) & 0x7F);
						fprintf(OutFile,"%c",data[0]);
						fprintf(OutFile,"%c",data[1]);
						if(is_debug){
							printf("  Delta Time:%02X%02X    (%8d)\n",data[0]&0xFF,data[1]&0xFF,deltatime);
						}
					} else if(is_ev_s_d <  0x80){ is_ev_s_s+=1;
						data[0]=0x00 | ((deltatime      ) & 0x7F);
						fprintf(OutFile,"%c",data[0]);
						if(is_debug){
							printf("  Delta Time:%02X      (%8d)\n",data[0]&0xFF,deltatime);
						}
					}
//					if(is_debug){
//						printf("  Delta Time:%02X%02X%02X%02X(%07x)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,deltatime);
//					}
					if(is_debug){
						printf("  Event : ");
					}
					for(i=0;i<512;i+=2) {
						strncpy(l,&is_ev_s_e[i],2);
						if(*l!=0x00){
							if(is_debug){
								printf("%02X",strtol(l, NULL, 16));
							}
							fprintf(OutFile,"%c",strtol(l, NULL, 16));
						}
					}
					if(is_debug){
						printf("\n");
					}
					ev_num++;
				}
				//Check event delete option
				if((is_ev_d == tr_num)&&(is_ev_d_n == ev_num)){
					ev_d=1;
				} else {
					ev_d=0;
				}
				//Delta Time
				data[0] = 0x00;
				data[1] = 0x00;
				data[2] = 0x00;
				data[3] = 0x00;
				data[0] = fgetc(InFile);chunksize--;
				deltatime=data[0]&0x7F;
				if(ev_d==0) fprintf(OutFile,"%c",data[0]);
				if((data[0]&0x80)==0x80){
					deltatime=deltatime*128;
					data[1] = fgetc(InFile);chunksize--;
					deltatime=deltatime+(data[1]&0x7F);
					if(ev_d==0) fprintf(OutFile,"%c",data[1]);
				}
				if((data[1]&0x80)==0x80){
					deltatime=deltatime*128;
					data[2] = fgetc(InFile);chunksize--;
					deltatime=deltatime+(data[2]&0x7F);
					if(ev_d==0) fprintf(OutFile,"%c",data[2]);
				}
				if((data[2]&0x80)==0x80){
					deltatime=deltatime*128;
					data[3] = fgetc(InFile);chunksize--;
					deltatime=deltatime+(data[3]&0x7F);
					if(ev_d==0) fprintf(OutFile,"%c",data[3]);
				}
				if(is_debug){
					if(ev_d==1){
						printf("event #%3d : %8d ****** Deleted ******\n",tr_num,ev_num);
					}else{
						printf("event #%3d : %8d\n",tr_num,ev_num);
					}
					if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)==0x80)) printf("  Delta Time:%02X%02X%02X%02X(%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,deltatime);
					if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)!=0x80)) printf("  Delta Time:%02X%02X%02X  (%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,deltatime);
					if(((data[0]&0x80)==0x80)&&((data[1]&0x80)!=0x80)                        ) printf("  Delta Time:%02X%02X    (%8d)\n",data[0]&0xFF,data[1]&0xFF,deltatime);
					if(((data[0]&0x80)!=0x80)                                                ) printf("  Delta Time:%02X      (%8d)\n",data[0]&0xFF,deltatime);
				}
				//Event
				data[0] = fgetc(InFile);chunksize--;
				if(data[0]==EOF){
					printf("EOF is detected.\n");
					exit(0);
				}
				ev_cnt=0;
				if((data[0]&0xFF)<0x80){
					ev_cnt=1;
					data[1]=data[0];
					data[0]=ev_prev;
				}
				ev_prev=(data[0]&0xFF);
				ev_num++;
//				if(ev_cnt==0) ev_num++;
				switch(data[0]&0xFF){
					case 0x80:
					case 0x81:
					case 0x82:
					case 0x83:
					case 0x84:
					case 0x85:
					case 0x86:
					case 0x87:
					case 0x88:
					case 0x89:
					case 0x8a:
					case 0x8b:
					case 0x8c:
					case 0x8d:
					case 0x8e:
					case 0x8f:
						if(ev_cnt==0){
							data[1] = fgetc(InFile);chunksize--;
						}
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							if(ev_cnt==0) printf("  Note Off:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==1) printf("  Note Off:  %02X%02X === Cont ===\n",data[1]&0xFF,data[2]&0xFF);
						}
						if(ev_d==0) {
							if(ev_cnt==0) fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0x90:
					case 0x91:
					case 0x92:
					case 0x93:
					case 0x94:
					case 0x95:
					case 0x96:
					case 0x97:
					case 0x98:
					case 0x99:
					case 0x9a:
					case 0x9b:
					case 0x9c:
					case 0x9d:
					case 0x9e:
					case 0x9f:
						if(ev_cnt==0){
							data[1] = fgetc(InFile);chunksize--;
						}
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							if(ev_cnt==0) printf("  Note On:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==1) printf("  Note On:  %02X%02X === Cont ===\n",data[1]&0xFF,data[2]&0xFF);
						}
						if(ev_d==0) {
							if(ev_cnt==0) fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0xa0:
					case 0xa1:
					case 0xa2:
					case 0xa3:
					case 0xa4:
					case 0xa5:
					case 0xa6:
					case 0xa7:
					case 0xa8:
					case 0xa9:
					case 0xaa:
					case 0xab:
					case 0xac:
					case 0xad:
					case 0xae:
					case 0xaf:
						if(ev_cnt==0){
							data[1] = fgetc(InFile);chunksize--;
						}
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							if(ev_cnt==0) printf("  Key After Touch:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==1) printf("  Key After Touch:  %02X%02X === Cont ===\n",data[1]&0xFF,data[2]&0xFF);
						}
						if(ev_d==0) {
							if(ev_cnt==0) fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0xb0:
					case 0xb1:
					case 0xb2:
					case 0xb3:
					case 0xb4:
					case 0xb5:
					case 0xb6:
					case 0xb7:
					case 0xb8:
					case 0xb9:
					case 0xba:
					case 0xbb:
					case 0xbc:
					case 0xbd:
					case 0xbe:
					case 0xbf:
						if(ev_cnt==0){
							data[1] = fgetc(InFile);chunksize--;
						}
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							if(ev_cnt==0) printf("  Control Change/Channel Mode:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==1) printf("  Control Change/Channel Mode:  %02X%02X === Cont ===\n",data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==0) printf("  Ch:%3d ",data[0]&0x0F);
							if(ev_cnt==1) printf("         ",data[0]&0x0F);
							switch(data[1]&0xFF){
								case 0:printf("Bank Select MSB:%02x\n",data[2]&0xFF);
								break;
								case 32:printf("Bank Select LSB:%02x\n",data[2]&0xFF);
								break;
								case 1:printf("Modulation:%02x\n",data[2]&0xFF);
								break;
								case 33:printf("Modulation LSB:%02x\n",data[2]&0xFF);
								break;
								case 2:printf("Breath Control:%02x\n",data[2]&0xFF);
								break;
								case 34:printf("Breath Control LSB:%02x\n",data[2]&0xFF);
								break;
								case 4:printf("Foot Control:%02x\n",data[2]&0xFF);
								break;
								case 36:printf("Foot Control LSB:%02x\n",data[2]&0xFF);
								break;
								case 5:printf("Portamento Time:%02x\n",data[2]&0xFF);
								break;
								case 37:printf("Portamento Time LSB:%02x\n",data[2]&0xFF);
								break;
								case 6:printf("Data Entry MSB:%02x\n",data[2]&0xFF);
								break;
								case 38:printf("Data Entry LSB:%02x\n",data[2]&0xFF);
								break;
								case 7:printf("Channel Volume:%02x\n",data[2]&0xFF);
								break;
								case 39:printf("Channel Volume LSB:%02x\n",data[2]&0xFF);
								break;
								case 8:printf("Balance:%02x\n",data[2]&0xFF);
								break;
								case 40:printf("Balance LSB:%02x\n",data[2]&0xFF);
								break;
								case 10:printf("Pan:%02x\n",data[2]&0xFF);
								break;
								case 42:printf("Pan LSB:%02x\n",data[2]&0xFF);
								break;
								case 11:printf("Expression:%02x\n",data[2]&0xFF);
								break;
								case 43:printf("Expression LSB:%02x\n",data[2]&0xFF);
								break;
								case 12:printf("Effect Control 1 MSB:%02x\n",data[2]&0xFF);
								break;
								case 44:printf("Effect Control 1 LSB:%02x\n",data[2]&0xFF);
								break;
								case 13:printf("Effect Control 2 MSB:%02x\n",data[2]&0xFF);
								break;
								case 45:printf("Effect Control 2 LSB:%02x\n",data[2]&0xFF);
								break;
								case 16:printf("General purpose Operator 1 MSB:%02x\n",data[2]&0xFF);
								break;
								case 48:printf("General purpose Operator 1 LSB:%02x\n",data[2]&0xFF);
								break;
								case 17:printf("General purpose Operator 2 MSB:%02x\n",data[2]&0xFF);
								break;
								case 49:printf("General purpose Operator 2 LSB:%02x\n",data[2]&0xFF);
								break;
								case 18:printf("General purpose Operator 3 MSB:%02x\n",data[2]&0xFF);
								break;
								case 50:printf("General purpose Operator 3 LSB:%02x\n",data[2]&0xFF);
								break;
								case 19:printf("General purpose Operator 4 MSB:%02x\n",data[2]&0xFF);
								break;
								case 51:printf("General purpose Operator 4 LSB:%02x\n",data[2]&0xFF);
								break;
								case 64:printf("Dumper Pedal:%02x\n",data[2]&0xFF);
								break;
								case 65:printf("Portamento (on/off):%02x\n",data[2]&0xFF);
								break;
								case 66:printf("Sostenuto (on/off):%02x\n",data[2]&0xFF);
								break;
								case 67:printf("Soft Pedal:%02x\n",data[2]&0xFF);
								break;
								case 68:printf("Legato Footswitch:%02x\n",data[2]&0xFF);
								break;
								case 69:printf("Hold2(Freeze):%02x\n",data[2]&0xFF);
								break;
								case 70:printf("Sound Control 1(Variation):%02x\n",data[2]&0xFF);
								break;
								case 71:printf("Sound Control 2(Harmonic Intense):%02x\n",data[2]&0xFF);
								break;
								case 72:printf("Sound Control 3(Release Time):%02x\n",data[2]&0xFF);
								break;
								case 73:printf("Sound Control 4(Attack Time):%02x\n",data[2]&0xFF);
								break;
								case 74:printf("Sound Control 5(Brightness):%02x\n",data[2]&0xFF);
								break;
								case 75:printf("Sound Control 6(Decay Time):%02x\n",data[2]&0xFF);
								break;
								case 76:printf("Sound Control 7(Vibrato Rate):%02x\n",data[2]&0xFF);
								break;
								case 77:printf("Sound Control 8(Vibrato Depth):%02x\n",data[2]&0xFF);
								break;
								case 78:printf("Sound Control 9(Vibrato Delay):%02x\n",data[2]&0xFF);
								break;
								case 79:printf("Sound Control 10:%02x\n",data[2]&0xFF);
								break;
								case 80:printf("General purpose Operator 5:%02x\n",data[2]&0xFF);
								break;
								case 81:printf("General purpose Operator 6:%02x\n",data[2]&0xFF);
								break;
								case 82:printf("General purpose Operator 7:%02x\n",data[2]&0xFF);
								break;
								case 83:printf("General purpose Operator 8:%02x\n",data[2]&0xFF);
								break;
								case 84:printf("Source Note:%02x\n",data[2]&0xFF);
								break;
								case 88:printf("High Resolution Velocity Prefix:%02x\n",data[2]&0xFF);
								break;
								case 91:printf("Effect 1(Reverb Send) Depth:%02x\n",data[2]&0xFF);
								break;
								case 92:printf("Effect 2(Tremolo) Depth:%02x\n",data[2]&0xFF);
								break;
								case 93:printf("Effect 3(Cholus) Depth:%02x\n",data[2]&0xFF);
								break;
								case 94:printf("Effect 4(Variation(Celeste)) Depth:%02x\n",data[2]&0xFF);
								break;
								case 95:printf("Effect 5(Phaser) Depth:%02x\n",data[2]&0xFF);
								break;
								case 96:printf("Data Increment\n");
								break;
								case 97:printf("Data Decrement\n");
								break;
								case 98:printf("NRPM LSB:%02x\n",data[2]&0xFF);
								break;
								case 99:printf("NRPM MSB:%02x\n",data[2]&0xFF);
								break;
								case 100:printf("RPM LSB:%02x\n",data[2]&0xFF);
								break;
								case 101:printf("RPM MSB:%02x\n",data[2]&0xFF);
								break;
								case 120:printf("All Sound Off:%02x\n",data[2]&0xFF);
								break;
								case 121:printf("Reset All Controller:%02x\n",data[2]&0xFF);
								break;
								case 122:printf("Local Control:%02x\n",data[2]&0xFF);
								break;
								case 123:printf("All Note Off:%02x\n",data[2]&0xFF);
								break;
								case 124:printf("OMNI Off:%02x\n",data[2]&0xFF);
								break;
								case 125:printf("OMNI On:%02x\n",data[2]&0xFF);
								break;
								case 126:printf("Mono Mode:%02x\n",data[2]&0xFF);
								break;
								case 127:printf("Poly Mode:%02x\n",data[2]&0xFF);
								break;
								default:printf("Undefined %02x:%02x\n",data[1]&0xFF,data[2]&0xFF);
							}
						}
						if(ev_d==0) {
							if(ev_cnt==0) fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0xc0:
					case 0xc1:
					case 0xc2:
					case 0xc3:
					case 0xc4:
					case 0xc5:
					case 0xc6:
					case 0xc7:
					case 0xc8:
					case 0xc9:
					case 0xca:
					case 0xcb:
					case 0xcc:
					case 0xcd:
					case 0xce:
					case 0xcf:
						data[1] = fgetc(InFile);chunksize--;
						if(is_debug){
							printf("  Program Change:%02X%02X\n",data[0]&0xFF,data[1]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
						}
					break;
					case 0xd0:
					case 0xd1:
					case 0xd2:
					case 0xd3:
					case 0xd4:
					case 0xd5:
					case 0xd6:
					case 0xd7:
					case 0xd8:
					case 0xd9:
					case 0xda:
					case 0xdb:
					case 0xdc:
					case 0xdd:
					case 0xde:
					case 0xdf:
						data[1] = fgetc(InFile);chunksize--;
						if(is_debug){
							printf("  Channel After Touch:%02X%02X\n",data[0]&0xFF,data[1]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
						}
					break;
					case 0xe0:
					case 0xe1:
					case 0xe2:
					case 0xe3:
					case 0xe4:
					case 0xe5:
					case 0xe6:
					case 0xe7:
					case 0xe8:
					case 0xe9:
					case 0xea:
					case 0xeb:
					case 0xec:
					case 0xed:
					case 0xee:
					case 0xef:
						if(ev_cnt==0){
							data[1] = fgetc(InFile);chunksize--;
						}
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							if(ev_cnt==0) printf("  Pitch Bend:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
							if(ev_cnt==1) printf("  Pitch Bend:  %02X%02X === Cont ===\n",data[1]&0xFF,data[2]&0xFF);
						}
						if(ev_d==0) {
							if(ev_cnt==0) fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0xf1:
						data[1] = fgetc(InFile);chunksize--;
						if(is_debug){
							printf("  MIDI TIme Code:%02X%02X\n",data[0]&0xFF,data[1]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
						}
					break;
					case 0xf2:
						data[1] = fgetc(InFile);chunksize--;
						data[2] = fgetc(InFile);chunksize--;
						if(is_debug){
							printf("  Song Position:%02X%02X%02X\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
							fprintf(OutFile,"%c",data[2]);
						}
					break;
					case 0xf3:
						data[1] = fgetc(InFile);chunksize--;
						if(is_debug){
							printf("  Song Number:%02X%02X\n",data[0]&0xFF,data[1]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
						}
					break;
					case 0xf6:
						if(is_debug){
							printf("  Tune Request:%02X%02X%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xf8:
						if(is_debug){
							printf("  MIDI Clock:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xfa:
						if(is_debug){
							printf("  MIDI Start:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xfb:
						if(is_debug){
							printf("  MIDI Continue:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xfc:
						if(is_debug){
							printf("  MIDI Stop:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xfe:
						if(is_debug){
							printf("  Active Sencing:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
					break;
					case 0xf0:
					case 0xf7:
						if(is_debug){
							printf("  System Exclusive:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
						}
						//Data Length
						data[0] = 0x00;
						data[1] = 0x00;
						data[2] = 0x00;
						data[3] = 0x00;
						data[0] = fgetc(InFile);chunksize--;
						datalength=data[0]&0x7F;
						if(ev_d==0) fprintf(OutFile,"%c",data[0]);
						if((data[0]&0x80)==0x80){
							datalength=datalength*128;
							data[1] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[1]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[1]);
						}
						if((data[1]&0x80)==0x80){
							datalength=datalength*128;
							data[2] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[2]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[2]);
						}
						if((data[2]&0x80)==0x80){
							datalength=datalength*128;
							data[3] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[3]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[3]);
						}
						if(is_debug){
//							printf("   Data Length:%02X%02X%02X%02X(%07x)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)==0x80)) printf("  Data Length:%02X%02X%02X%02X(%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)!=0x80)) printf("  Data Length:%02X%02X%02X  (%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)!=0x80)                        ) printf("  Data Length:%02X%02X    (%8d)\n",data[0]&0xFF,data[1]&0xFF,datalength);
							if(((data[0]&0x80)!=0x80)                                                ) printf("  Data Length:%02X      (%8d)\n",data[0]&0xFF,datalength);
						}
						if(is_debug){
							printf("   Data:");
						}
						while(datalength>0){
							data[0] = fgetc(InFile);chunksize--;
							if(ev_d==0) fprintf(OutFile,"%c",data[0]);
							datalength--;
							if(is_debug){
								printf("%02X",data[0]&0xFF);
							}
						}
						if(is_debug){
							printf("\n");
						}
					break;
					case 0xff:
						data[1] = fgetc(InFile);chunksize--;
						ev_typ=(data[1]&0xFF);
						if(is_debug){
							printf("  Meta Event:%02X%02X ",data[0]&0xFF,data[1]&0xFF);
							switch(ev_typ){
								case 0x00:printf("[Sequence Number]\n");
								break;
								case 0x01:printf("[Text Event]\n");
								break;
								case 0x02:printf("[Copyright Notice]\n");
								break;
								case 0x03:printf("[Sequence/Track Name]\n");
								break;
								case 0x04:printf("[Instrument Name]\n");
								break;
								case 0x05:printf("[Lyric]\n");
								break;
								case 0x06:printf("[Marker]\n");
								break;
								case 0x07:printf("[Cue Point]\n");
								break;
								case 0x20:printf("[Channel Prefix]\n");
								break;
								case 0x21:printf("[Port Prefix]\n");
								break;
								case 0x2f:printf("[End of Track]\n");
								break;
								case 0x51:printf("[Set Tempo]\n");
								break;
								case 0x54:printf("[SMPTE Offset]\n");
								break;
								case 0x58:printf("[Time Signature]\n");
								break;
								case 0x59:printf("[Key Signature]\n");
								break;
								case 0x7f:printf("[Sequencer-Specific Meta-Event]\n");
								break;
								default:printf("\n");
								break;
							}
						}
						if(ev_d==0) {
							fprintf(OutFile,"%c",data[0]);
							fprintf(OutFile,"%c",data[1]);
						}
						//Data Length
						data[0] = 0x00;
						data[1] = 0x00;
						data[2] = 0x00;
						data[3] = 0x00;
						data[0] = fgetc(InFile);chunksize--;
						datalength=data[0]&0x7F;
						if(ev_d==0) fprintf(OutFile,"%c",data[0]);
						if((data[0]&0x80)==0x80){
							datalength=datalength*128;
							data[1] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[1]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[1]);
						}
						if((data[1]&0x80)==0x80){
							datalength=datalength*128;
							data[2] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[2]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[2]);
						}
						if((data[2]&0x80)==0x80){
							datalength=datalength*128;
							data[3] = fgetc(InFile);chunksize--;
							datalength=datalength+(data[3]&0x7F);
							if(ev_d==0) fprintf(OutFile,"%c",data[3]);
						}
						if(is_debug){
//							printf("   Data Length:%02X%02X%02X%02X(%07x)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)==0x80)) printf("  Data Length:%02X%02X%02X%02X(%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,data[3]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)==0x80)&&((data[2]&0x80)!=0x80)) printf("  Data Length:%02X%02X%02X  (%8d)\n",data[0]&0xFF,data[1]&0xFF,data[2]&0xFF,datalength);
							if(((data[0]&0x80)==0x80)&&((data[1]&0x80)!=0x80)                        ) printf("  Data Length:%02X%02X    (%8d)\n",data[0]&0xFF,data[1]&0xFF,datalength);
							if(((data[0]&0x80)!=0x80)                                                ) printf("  Data Length:%02X      (%8d)\n",data[0]&0xFF,datalength);
						}
						if(is_debug){
							printf("   Data:");
						}
						j=0;
//						while(datalength>0){
						while(j<datalength){
							data[j] = fgetc(InFile);chunksize--;
							if(ev_d==0) fprintf(OutFile,"%c",data[j]);
//							datalength--;
							if(is_debug){
//								if(ev_typ<8) printf("%c",data[j]&0xFF);
//								if(ev_typ>=8) printf("%02X",data[j]&0xFF);
								printf("%02X",data[j]&0xFF);
							}
							j++;
						}
						if(is_debug){
							switch(ev_typ){
								case 0x00://printf("[Sequence Number]\n");
								case 0x01://printf("[Text Event]\n");
								case 0x02://printf("[Copyright Notice]\n");
								case 0x03://printf("[Sequence/Track Name]\n");
								case 0x04://printf("[Instrument Name]\n");
								case 0x05://printf("[Lyric]\n");
								case 0x06://printf("[Marker]\n");
								case 0x07://printf("[Cue Point]\n");
									printf("\n   Text:");
									for(j=0;j<datalength;j++){
										printf("%c",data[j]&0xFF);
									}
								break;
								case 0x20://printf("[Channel Prefix]\n");
								break;
								case 0x21://printf("[Port Prefix]\n");
								break;
								case 0x2f://printf("[End of Track]\n");
								break;
								case 0x51://printf("[Set Tempo]\n");
									printf(" (Tempo=%4d)",60000000/((data[0]&0xFF)*256*256+(data[1]&0xFF)*256+(data[2]&0xFF)));
								break;
								case 0x54://printf("[SMPTE Offset]\n");
								break;
								case 0x58://printf("[Time Signature]\n");
									printf(" (Beat=%4d/%4d MidiClock=%4d)",(data[0]&0xFF),1<<(data[1]&0xFF),(data[2]&0xFF));
								break;
								case 0x59://printf("[Key Signature]\n");
									printf(" (sf=%2d ml=%2d)",(data[0]&0xFF),(data[1]&0xFF));
								break;
								case 0x7f://printf("[Sequencer-Specific Meta-Event]\n");
								break;
								default:
								break;
							}
						}
						if(is_debug){
							printf("\n");
						}
					break;
					default:
						if(is_debug){
							printf("  Unknown:%02X\n",data[0]&0xFF);
						}
						if(ev_d==0) fprintf(OutFile,"%c",data[0]);
					break;
				}
			}
			if(is_debug){
				printf("//----------------------------------------------------------\n");
			}

			if(tr_num >= track){
				k=1;
			}
		}
	}
	fclose(InFile);
	fclose(OutFile);
//	if(SFile!=NULL) fclose(SFile);
	
exit(0);

}
