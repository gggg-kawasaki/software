#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <time.h>

void main(int argc, char **argv){
	int data[256];
	int i,j,k;
	int wdata;
//	int form;
//	int shownum,num;

	char OutFileName[256];
	FILE *InFile,*OutFile;
 
	if(argc<3){
		printf("H2B : hex to binary\n");
		printf("h2b infile outfile\n");
		exit(0);
	}
	InFile = fopen(argv[1],"rb" );
	if((InFile==NULL)||(ferror(InFile))){
		printf(" Input File Error\n"); 
		exit(0);
	}
	OutFile = fopen(argv[2],"wb" );
	if((OutFile==NULL)||(ferror(OutFile))){
		printf(" Output File Error\n"); 
		exit(0);
	}
//		printf("1\n"); 
	// initialize array
	for(i=0;i<256;i++) data[i]=0x00;

//	form=0;
//	shownum=0;
//	num=0;

	if(argc>3){
		for(i=3;i<argc;i++) {
//			if (strncmp(argv[i],"-f0",3) == 0)
//				form=0;
//			else if (strncmp(argv[i],"-f1",3) == 0)
//				form=1;
//			else if (strncmp(argv[i],"-f2",3) == 0)
//				form=2;
//			else if (strncmp(argv[i],"-n",2) == 0)
//				shownum=1;
//			else {
				fprintf(stderr,"Unknown %s\n",argv[i]);
				exit(-1);
//			}
		}
	}
//		printf("2\n"); 
	k=0;
	data[0] = fgetc(InFile);
	if(data[0]==EOF) exit(0);
	while(k==0){ 
		data[1] = fgetc(InFile);
		if(data[1]==EOF) exit(0);
		if(
			(((data[0] >= 0x30)&&(data[0] <= 0x39))||((data[0] >= 0x41)&&(data[0] <= 0x46))||((data[0] >= 0x61)&&(data[0] <= 0x66)))&&
			(((data[1] >= 0x30)&&(data[1] <= 0x39))||((data[1] >= 0x41)&&(data[1] <= 0x46))||((data[1] >= 0x61)&&(data[1] <= 0x66)))
		){
			wdata=0;
			if((data[0] >= 0x30)&&(data[0] <= 0x39)) wdata = (data[0]-0x30)*16;
			if((data[0] >= 0x41)&&(data[0] <= 0x46)) wdata = (data[0]-0x41+0x0A)*16;
			if((data[0] >= 0x61)&&(data[0] <= 0x66)) wdata = (data[0]-0x61+0x0A)*16;
			if((data[1] >= 0x30)&&(data[1] <= 0x39)) wdata = wdata + (data[1]-0x30);
			if((data[1] >= 0x41)&&(data[1] <= 0x46)) wdata = wdata + (data[1]-0x41+0x0A);
			if((data[1] >= 0x61)&&(data[1] <= 0x66)) wdata = wdata + (data[1]-0x61+0x0A);
			fprintf(OutFile,"%c",(char)(wdata&0xFF));
			data[0] = 0;data[1] = 0;
		} else {
			data[0]=data[1];
		}
	}
	fclose(InFile);
	fclose(OutFile);
}
