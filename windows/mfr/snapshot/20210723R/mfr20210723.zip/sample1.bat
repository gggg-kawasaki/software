REM No Option
mfr in\onestop.mid out\onestop_x.mid > out\onestop_x.log
REM GM Reset
mfr in\onestop.mid out\onestop_gm.mid -a 1 2 0 F0057E7F0901F7 > out\onestop_gm.log
REM XG Reset
mfr in\onestop.mid out\onestop_xg.mid -a 1 2 0 F00843104C00007E00F7 > out\onestop_xg.log
REM GS Reset
mfr in\onestop.mid out\onestop_gs.mid -a 1 2 0 F00A4110421240007F0041F7 > out\onestop_gs.log
REM GM->XG Reset
mfr in\onestop.mid out\onestop_gmxg.mid -a 1 2 0 F0057E7F0901F700F00843104C00007E00F7 > out\onestop_gmxg.log
REM GM->GS Reset
mfr in\onestop.mid out\onestop_gmgs.mid -a 1 2 0 F0057E7F0901F700F00A4110421240007F0041F7 > out\onestop_gmgs.log
