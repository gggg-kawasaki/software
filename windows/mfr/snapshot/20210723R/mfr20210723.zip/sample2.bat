REM GM->XG Reset
mfr in\onestop.mid tmp1.mid -a 1 2 0 F0057E7F0901F700F00843104C00007E00F7 >tmpxx.log
REM XG system effect setting
REM = Reverb =
mfr tmp1.mid tmp2.mid -a 1 4 0 F00943104C0201000101F7 >tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 5 0 F00843104C02010212F7 >tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 6 0 F00843104C0201030AF7 >tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 7 0 F00843104C02010408F7 >tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 8 0 F00843104C0201050DF7 >tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 9 0 F00843104C02010631F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 10 0 F00843104C02010C40F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 11 0 F00843104C02010D40F7> tmpxx.log
REM = Chorus =
mfr tmp1.mid tmp2.mid -a 1 12 0 F00943104C0201204100F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 13 0 F00843104C02012206F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 14 0 F00843104C02012336F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 15 0 F00843104C0201244DF7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 16 0 F00843104C0201256AF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 17 0 F00843104C02012600F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 18 0 F00843104C0201271CF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 19 0 F00843104C02012840F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 20 0 F00843104C0201292EF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 21 0 F00843104C02012A40F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 22 0 F00843104C02012C40F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 23 0 F00843104C02012D40F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 24 0 F00843104C02012E40F7> tmpxx.log
REM = Variation =
mfr tmp2.mid tmp1.mid -a 1 25 0 F00943104C0201400500F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 26 0 F00943104C0201421A05F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 27 0 F00943104C0201440D03F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 28 0 F00943104C0201462708F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 29 0 F00943104C0201482708F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 30 0 F00943104C02014A004AF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 31 0 F00943104C02014C0064F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 32 0 F00943104C02014E000AF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 33 0 F00943104C0201500000F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 34 0 F00943104C0201520000F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 35 0 F00943104C0201540020F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 36 0 F00843104C02015640F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 37 0 F00843104C02015740F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 38 0 F00843104C02015800F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 39 0 F00843104C02015900F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 40 0 F00843104C02015A01F7> tmpxx.log
REM = 5 BAND EQ =
mfr tmp2.mid tmp1.mid -a 1 41 0 F00843104C02400002F7> tmpxx.log
REM = INSERSION 1 =
mfr tmp1.mid tmp2.mid -a 1 42 0 F00943104C0300004B08F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 43 0 F00843104C0300020DF7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 44 0 F00843104C03000303F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 45 0 F00843104C03000434F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 46 0 F00843104C0300057FF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 47 0 F00843104C0300207FF7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 48 0 F00843104C03000C0FF7> tmpxx.log
REM = INSERSION 2 =
mfr tmp2.mid tmp1.mid -a 1 49 0 F00943104C0301004B08F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 50 0 F00843104C0301020DF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 51 0 F00843104C03010303F7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 52 0 F00843104C03010434F7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 53 0 F00843104C0301057FF7> tmpxx.log
mfr tmp1.mid tmp2.mid -a 1 54 0 F00843104C0301207FF7> tmpxx.log
mfr tmp2.mid tmp1.mid -a 1 55 0 F00843104C03010C07F7> tmpxx.log
REM Apply variation
mfr tmp1.mid tmp2.mid -a 1 56 0 B05E1800B25E1800B45E2000B65E2000B85E20 > tmpxx.log
REM Replace Sequence/Track Name
mfr tmp2.mid tmp1.mid -a 1 1 0 FF03284F6E652053746F70202F204461766964205961636B6C6579202F20666F72204D5532303030205847 -d 1 2 12 > tmpxx.log
mfr tmp1.mid out\onestop_mu2k.mid > out\onestop_mu2k.log

